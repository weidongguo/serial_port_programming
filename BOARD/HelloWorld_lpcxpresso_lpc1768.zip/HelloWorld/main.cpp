#include "mbed.h"

DigitalOut leds[] = {DigitalOut(LED1), DigitalOut(LED2), DigitalOut(LED3), DigitalOut(LED4)}; // put each LED object into an array, easier to access
PwmOut led_pwm(LED1); // control the brightness of LED
Serial pc(USBTX, USBRX);

void ledCycle(){
   int on = 0;
   while(1) {
        on = on ^ 1; //toggle ;
        for(int i = 0; i < sizeof(leds) / sizeof(DigitalOut); i++){
            leds[i] = on;
            wait(0.3);  // 0.3 sec
        }
    }   
}
void ledBrightness(){
    pc.baud(115200);
    pc.printf("Control Brightness of LED 1\n");    
    char ch;
    float brightness = 0.0;
    while(1){
        ch = pc.getc();
        pc.putc(ch);    
        if( ch == 'k' && brightness < 1.0){
            brightness += 0.05;
            led_pwm = brightness;
        }
        else if( ch == 'j' && brightness > 0.0){
            brightness -= 0.05;
            led_pwm = brightness;    
        }
        else if( ch >= '1' && ch <= '4')
            leds[ch - '0' - 1] = !leds[ch - '0' - 1];
        
    }
}

int main() {
    ledBrightness();
}
